/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cryptography;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

/**
 *
 * @author LATITUDE 7480
 */
public class Cryptography {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {

        String str, reponse = "";

        String directory = System.getProperty("user.home");
        String fileName = "a.txt";
        String fileName1 = "b.txt";
        String absolutePath = directory + File.separator + fileName;
        String absolutePath1 = directory + File.separator + fileName1;
        //--------------------
        System.out.print("1. Encryption\n2. Decryption\nChoose(1,2): ");
        Scanner in = new Scanner(System.in);
        int choice = in.nextInt();

        switch (choice) {
            case 1:

                System.out.println("Encryption");
                in.nextLine();
                BufferedReader ligne = new BufferedReader(new FileReader(absolutePath));

                System.out.print("Enter le clé : ");  
                int cle = in.nextInt();
                System.out.println("Entre la phrase à coder");
                str = ligne.readLine();
                System.out.println(str);
                for (int i = 0; i < str.length(); i++) {
                    char ch = str.charAt(i);
                    if (Character.isLetter(ch)) {

                        int ascii = (int) ch;

                        if (Character.isUpperCase(ch)) {
                            ascii += cle;
                            if (ascii > 90) {
                                ascii -= 26;
                            }
                            ch = (char) ascii;

                            reponse += ch;

                        }

                        if (Character.isLowerCase(ch)) {
                            ascii += cle;
                            if (ascii > 122) {
                                ascii -= 26;
                            }
                            ch = (char) ascii;

                            reponse += ch;

                        }
                    } else {

                        reponse += ch;
                    }
                }
                System.out.println("Encryption  :" + reponse);

                try (BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(absolutePath1))) {
                    String fileContent = reponse;
                    bufferedWriter.write( reponse);
                } catch (IOException e) {
                    // Exception handling
                }
                break;
            case 2:

                System.out.println("Decryption");
                in.nextLine();
                BufferedReader br = new BufferedReader(new FileReader(absolutePath1));
                System.out.print("Enter le clé : ");  
                int cle1 = in.nextInt();
                System.out.println("Entre la phrase à décoder");
                str = br.readLine();
                System.out.println(str);
                for (int i = 0; i < str.length(); i++) {
                    char ch = str.charAt(i);
                    if (Character.isLetter(ch)) {
                        int ascii = (int) ch;

                        if (Character.isUpperCase(ch)) {
                            ascii -= cle1;
                            if (ascii < 65) {
                                ascii += 26;
                            }
                            ch = (char) ascii;

                            reponse += ch;

                        }

                        if (Character.isLowerCase(ch)) {
                            ascii -= cle1;
                            if (ascii < 97) {
                                ascii += 26;
                            }
                            ch = (char) ascii;
                            reponse += ch;
                        }
                    } else {
                        reponse += ch;
                    }
                }

                System.out.println("Decryption  :" + reponse);
                try (BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(absolutePath))) {
                    String fileContent = reponse;
                    bufferedWriter.write(reponse);
                } catch (IOException e) {
                    // Exception handling
                }
                break;
            default:
                System.out.println("erreur");
                break;
        }
    }
}
